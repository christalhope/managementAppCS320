
import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
		Contact contact = new Contact("1231231231", "Christal", "Willett", "3527017206", "123 Myway Lane");
		Assert.assertTrue(Contact.getContactID().equals("1231231231"));
		Assert.assertTrue(Contact.getContactFirstName().equals("Christal"));
		Assert.assertTrue(Contact.getContactLastName().equals("Willett"));
		Assert.assertTrue(Contact.getContactPhone().equals("3527017206"));
		Assert.assertTrue(Contact.getContactAddress().equals("123 Myway Lane"));
	}
	
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("0001231231231", "Christal", "Willett", "3527017206", "123 Myway Lane");
		});
	}
	

}