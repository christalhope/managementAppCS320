import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskTest {
	
	@Test
	void testTask() {
		
		Task task = new Task("0000000001", "TaskNameConvention01", "This is the very first task of the task program..");
		assertTrue(task.getTask_ID().equals("0000000001"));
		assertTrue(task.getTask_Name().equals("TaskNameConvention01"));
		assertTrue(task.getTask_Description().equals("This is the very first task of the task program.."));
	}

	@Test
	void testTaskIdTooLong() {
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Task("00000000001", "TaskNameConvention01", "This is the very first task of the task program..");
		});		}
	
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Task("0000000001", "TaskNameConvention001", "This is the very first task of the task program..");
		});		}
	
	@Test
	void testTaskDescriptionTooLong() {
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Task("0000000001", "TaskNameConvention01", "This is the very first task of the task program.. This is the very first task of the task program..");
		});		}
}
