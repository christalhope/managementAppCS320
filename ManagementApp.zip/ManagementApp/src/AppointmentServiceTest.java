import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import java.util.Scanner;

class AppointmentServiceTest {

	@Test
	void testAddAppointment() {
		
		Scanner s = new Scanner("0001 2023-10-2 AppointmentDescription");
		AppointmentService.addAppointment(s);
	}
	
	@Test
	void testDeleteAppointment() {
		
		Scanner s = new Scanner("0001 TestAppointmentDate AppointmentDescription");
		AppointmentService.deleteAppointment(s);
	}
}
