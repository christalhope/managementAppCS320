import java.util.Comparator;

public class Task {

	private String task_ID;
	private String task_Name;
	private String task_Description; // member variables declared

	public static Comparator<Task> compareById = new Comparator<Task>() { // for comparing task object IDs

		@Override
			public int compare(Task first_Task, Task second_Task) {
			return first_Task.getTask_ID().compareTo(second_Task.getTask_ID()); // to compare task objects
		}
	};

	public String getTask_ID() {

		return task_ID;
	}

	public String getTask_Name() {

		return task_Name;
	}

	public String getTask_Description() {

		return task_Description;
	}

	public void setTask_ID(String task_ID) {

		if(task_ID == null || task_ID.length() > 10) {
			
			throw new RuntimeException("ID cannot exceed 10 characters."); // throw exception if null or more than 10 char
		} 
		
		else {
			
			this.task_ID = task_ID;
		}
	}

	public void setTask_Name(String task_Name) {

		if(task_Name == null || task_Name.length() > 20) {
			
			throw new RuntimeException("Name cannot exceed 20 characters."); // throw exception if null or more than 20 char
		} 
		
		else {
			
			this.task_Name = task_Name;
		}
	}

	public void setTask_Description(String task_Description) { // setter & getter methods

		if(task_Description == null || task_Description.length() > 50) {
			
			throw new RuntimeException("Description cannot exceed 50 characters."); // throw runtime exception if null or over 50 char
		} 
		
		else {
			
			this.task_Description = task_Description;
		}
	}
	
	public Task(String task_ID, String task_Name, String task_Description) { // constructor declared & defined
		
		setTask_ID(task_ID);
		setTask_Name(task_Name);
		setTask_Description(task_Description);
		
	}
}
