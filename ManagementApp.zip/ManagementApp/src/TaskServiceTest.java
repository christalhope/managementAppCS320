import java.util.Scanner;

import org.junit.jupiter.api.Test;

class TaskServiceTest {

	@Test
	void testAddTask() {
		
		Scanner s = new Scanner("0001 TestTaskName TaskDescription");
		TaskService.addTask(s);
	}
	
	@Test
	void testDeleteTask() {
		
		Scanner s = new Scanner("0001 TestTaskName TaskDescription");
		TaskService.deleteTask(s);
	}
	
	@Test
	void testUpdateTask() {
		
		Scanner s = new Scanner("0002 TaskName TaskDescription123");
		TaskService.updateTask(s);
	}
	
}
