import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentTest {

	@Test
	void testAppointment() {
		
		Date date = new Date(2023-4-1);
		
		Appointment appointment = new Appointment("0000000012", date, "Description of appointment");
		assertTrue(appointment.getAppointment_ID().equals("0000000012"));
		assertTrue(appointment.getAppointment_Date().equals(date));
		assertTrue(appointment.getAppointment_Description().equals("Description of appointment"));
	}

	@Test
	void testAppointmentDateInvalid(Date date) {
		
		Date date2 = new Date();
		
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Appointment("0000000012", date2, "This is the very first appointment of the program..");
		});		}
	
	@Test
	void testAppointmentIdTooLong() {
		
		Date date3 = new Date();
		
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Appointment("00000000122", date3, "Description of appointment");
		});		}
	
	@Test
	void testAppointmentDescriptionTooLong() {
		
		Date date4 = new Date();
		
		Assertions.assertThrows(RuntimeException.class, () -> {
			new Appointment("0000000001", date4, "Description of appointment. Description of appointment. Description of appointment. Description of appointment. Description of appointment");
		});		}
}
