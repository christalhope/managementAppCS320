
import static org.junit.jupiter.api.Assertions.*;

import java.util.Scanner;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContact() {
			
		Scanner s = new Scanner("0001 ContactName ContactDescription");
		ContactService.addContact(s);
	}
	
	@Test
	void testDeleteContact() {
		
		Scanner s = new Scanner("0001 ContactName ContactDescription");
		ContactService.deleteContact(s);
	}
	
	@Test
	void testUpdateContact() {
		
		Scanner s = new Scanner("0002 ContactName ContactDescription123");
		ContactService.updateContact(s);
	}
	
	@Test
	void testSearchContact() {
		
		Scanner s = new Scanner("0002 ContactName ContactDescription123");
		ContactService.searchContact(s);
		
	}

}

