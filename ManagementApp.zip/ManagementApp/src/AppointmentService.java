
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class AppointmentService {
	
	public static ArrayList<Appointment> myAppointments = new ArrayList<Appointment>(); // array of appointments
	
	public static void main(String[] args) {
		
	    Scanner s = new Scanner(System.in);
	    
	    int option;
		do {
		    System.out.println("1. Add Appointment");
		    System.out.println("2. Delete Appointment");
		    System.out.println("3. Exit");
		    System.out.println("Please choose an option: "); // options menu
		    option = s.nextInt();
		    
		    switch (option) {
		    
		        case 1:
		            addAppointment(s); // to add appointment
		            break;
		            
		        case 2:
		            deleteAppointment(s); // to delete appointment
		            break;
		            
		        case 3:
		            break;
		            
		        default:
		            System.out.println("Please choose a valid option.");
		            break;
		    }
		}
		
		while (option != 3);
		}
	
	public static void addAppointment(Scanner s) { // add appointment w/ unique id
		
		String appointmentDescription;
		Date appointmentDate = null;

		System.out.println("Please enter unique appointment ID."); // user to input unique appointment id
		String appointmentId = s.next();
		System.out.println("Please enter description of appointment."); // appointment description
		appointmentDescription = s.next();

		Appointment someAppointment = new Appointment(appointmentId, appointmentDate, appointmentDescription); // new array item object

		myAppointments.add(someAppointment);

		System.out.println("Appointment has been added to the system."); // output when task is saved
		}

	public static void deleteAppointment(Scanner s) { // remove task object from array list
		
		String appointmentId;
		
		boolean appointmentExists = false;
		System.out.println("Enter ID of the appointment you'd like to remove.");
		appointmentId = s.next();
		
		Appointment removeAppointment = null;
		for (Appointment appointment:myAppointments) {

			if (appointment.getAppointment_ID() == appointmentId) { // if id entered is in the system, that task is "selected"

				removeAppointment = appointment;
				appointmentExists = true;
			}
		}

		if (!appointmentExists) {

			System.out.println("Appointment not found."); // called if appointment id does not exist
		}
		else {
			myAppointments.remove(removeAppointment);
			System.out.println("Appointment has been deleted."); // appointment removed using task id
		}
		
	}
}
