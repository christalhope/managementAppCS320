
import java.util.Date;

public class Appointment {

	private String appointment_ID;
	private Date appointment_Date;
	private String appointment_Description; // appointment class variables declared

	public String getAppointment_ID() {

		return appointment_ID;
	}

	public Date getAppointment_Date() {

		return appointment_Date;
	}

	public String getAppointment_Description() { // getter methods

		return appointment_Description;
	}

	public void setAppointment_ID(String appointment_ID) {

		if(appointment_ID == null || appointment_ID.length() > 10) {
			
			throw new IllegalArgumentException("ID cannot exceed 10 characters."); // throw exception if null or more than 10 char
		} 
		
		else {
			
			this.appointment_ID = appointment_ID;
		}
	}

	public void setAppointment_Date(Date appointment_Date) {

		if(appointment_Date == null || appointment_Date.before(new Date())) {
			
			throw new IllegalArgumentException("Must have a valid date."); // throw exception if null or more than 20 char
		} 
		
		else {
				
			this.appointment_Date = appointment_Date;
		}
	}

	public void setAppointment_Description(String appointment_Description) { // setter & getter methods

		if(appointment_Description == null || appointment_Description.length() > 50) {
			
			throw new IllegalArgumentException("Description cannot exceed 50 characters."); // throw runtime exception if null or over 50 characters
		} 
		
		else {
			
			this.appointment_Description = appointment_Description;
		}
	}
	
	public Appointment(String appointment_ID, Date appointment_Date, String appointment_Description) { // class constructor
		
		setAppointment_ID(appointment_ID);
		setAppointment_Date(appointment_Date);
		setAppointment_Description(appointment_Description);
		
	}
}
