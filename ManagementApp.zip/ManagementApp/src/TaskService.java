

import java.util.ArrayList;

import java.util.Scanner;


public class TaskService {

	public static ArrayList<Task> myTasks = new ArrayList<Task>(); // array of tasks declared
	
	public static void main(String[] args) {
	    Scanner s = new Scanner(System.in);


	int option;
	do {
	    System.out.println("1. Add Task");
	    System.out.println("2. Delete Task");
	    System.out.println("3. Update Task");
	    System.out.println("4. Exit");
	    System.out.println("Please choose an option: ");
	    option = s.nextInt();
	    
	    switch (option) {
	    
	        case 1:
	            addTask(s);
	            break;
	            
	        case 2:
	            deleteTask(s);
	            break;
	            
	        case 3:
	            updateTask(s);
	            break;
	            
	        case 4:
	            break;
	            
	        default:
	            System.out.println("Please choose a valid option.");
	            break;
	    }
	}
	
	while (option != 4);
	}
	
	public static void addTask(Scanner s) { // add task w/ unique id

		System.out.println("Please enter unique task ID."); // user to input unique task id
		String taskId = s.next();
		System.out.println("Please enter unique task name."); // task name
		String taskName = s.next();
		System.out.println("Please enter unique task description."); // description
		String taskDescription = s.next();

		Task someTask = new Task(taskId, taskName, taskDescription); // new array item object

		myTasks.add(someTask);

		System.out.println("Task has been added to the system."); // output when task is saved
		}
		

	public static void updateTask(Scanner s) { // update task with task ID
		
		String taskId;
		String taskName;
		String taskDescription;

		boolean exists = false;
		System.out.println("Enter ID of task you'd like to update."); // prompt user to enter ID of task needing updated
		taskId = s.next();

		for (Task task:myTasks) {

			if (task.getTask_ID() == taskId) {
				System.out.println("Update task name");
				taskName = s.next();
				System.out.println("Udate task description");
				taskDescription = s.next();
				task.setTask_Name(taskName);
				task.setTask_Description(taskDescription); // set user input equal to member variables
				System.out.println(task);
				exists = true;
			}

			if (!exists) {

				System.out.println("Task not found."); // called if ID is not in the system
			}
			else {
				System.out.println("Task has been updated."); // otherwise, task object has been updated
			}
		}
	}
	public static void deleteTask(Scanner s) { // remove task object from array list
		
		boolean exists = false;
		System.out.println("Enter ID of task that you'd like to remove.");
		String taskId = s.next();
		Task removeTask = null;
		for (Task task:myTasks) {

			if (task.getTask_ID() == taskId) { // if id entered is in the system, that task is "selected"

				removeTask = task;
				exists = true;
			}
		}

		if (!exists) {

			System.out.println("Task not found."); // called if task id does not exist
		}
		else {
			myTasks.remove(removeTask);
			System.out.println("Task has been deleted."); // task removed using task id
		}
	}

}
