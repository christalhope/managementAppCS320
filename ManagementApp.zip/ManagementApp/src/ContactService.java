
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class ContactService {
	
	List<Contact> myList = new ArrayList<Contact>();
	Scanner scanner = new Scanner(System.in);
	String contact_ID;
	boolean isFound = true;
	
	public int main() {
	
	int choice;
	do {
		
		System.out.println("1. Add Contact");
		System.out.println("2. Update Contact");
		System.out.println("3. Search Contact");
		System.out.println("4. Delete Contact");
		System.out.println("Please make a selection."); // user options 
		
		choice = scanner.nextInt();
		
		Object iterator;
		switch(choice) {
		
		case 1:
			System.out.println("Enter contact first name.");
			String first_Name = scanner.nextLine();
			System.out.println("Enter contact last name.");
			String last_Name = scanner.nextLine();
			System.out.println("Enter contact phone number.");
			String phone_Number = scanner.nextLine();
			System.out.println("Enter contact address.");
			String contact_Address = scanner.nextLine(); // user to input contact data
			
			myList.add(new Contact(contact_ID, first_Name, last_Name, phone_Number, contact_Address));
		break;
		case 2:
			isFound = false;
			
			System.out.println("Please enter the contact ID associated with the contact you'd like to update.");
			contact_ID = scanner.nextLine();
			ListIterator<Contact> myListIterator = myList.listIterator();
			while (myListIterator.hasNext()) {
				Contact c = myListIterator.next();
				if(c.getContactID() == contact_ID) {
					System.out.println("Please update contact info.");
					contact_ID = scanner.nextLine();
					
					System.out.println("Update first name.");
					first_Name = scanner.nextLine();
					myListIterator.set(new Contact(contact_ID, first_Name, last_Name, phone_Number, contact_Address));
					isFound = true;
				}
			
			break;
			}
			
		case 3:
			isFound = false;
			System.out.println("Enter contact ID to search for record");
			String contact_ID = scanner.nextLine();
			Iterator<Contact> iterator2 = myList.iterator();
			while (iterator2.hasNext()) {
				Contact c = iterator2.next();
				if(c.getContactID() == contact_ID) {
				System.out.println(c);
				isFound = true;
			}
			}
			
			if(!isFound) {
				System.out.println("Record does not exist.");
			} 
			else {
				System.out.println("Record has been updated.");
			}
			
			break;
			
		case 4:
			isFound = false;
			System.out.println("Enter contact ID to remove record");
			contact_ID = scanner.nextLine();
			Iterator<Contact> iterator3 = myList.iterator();
			while (iterator3.hasNext()) {
				Contact c = iterator3.next();
				if(c.getContactID() == contact_ID) {
				iterator3.remove();
				isFound = true;
			}
			}
			if(!isFound) {
				System.out.println("Record does not exist.");
			} else {
				System.out.println("Record has been deleted.");
			}
			break;

		while (choice != 0); 
		}
	}
	}
	
	
	public static void addContact(Scanner s) {
		// TODO Auto-generated method stub
	}
	
	public static void deleteContact(Scanner s) {
		// TODO Auto-generated method stub
	}
	
	public static void updateContact(Scanner s) {
		// TODO Auto-generated method stub
	}
	
	public static void searchContact(Scanner s) {
		// TODO Auto-generated method stub
	}
}

