
public class Contact {
	
	private static String contact_ID;
	private static String first_Name;
	private static String last_Name;
	private static String phone_Number;
	private static String contact_Address; // contact member variables
	
	
	public Contact(String contact_ID, String first_Name, String last_Name, String phone_Number, String contact_Address) {
		
		if (contact_ID == null || contact_ID.length() > 10) {
			
			throw new IllegalArgumentException("Invalid id");
		}
		
		if (first_Name == null || first_Name.length() > 10) {
			
				throw new IllegalArgumentException("Invalid first name");
		}
		
		if (last_Name == null || last_Name.length() > 10) {
	
			throw new IllegalArgumentException("Invalid last name");
		}
		
		if (phone_Number == null || phone_Number.length() > 10) {
	
			throw new IllegalArgumentException("Invalid phone number");
		}
		
		if (contact_Address == null || contact_Address.length() > 30) {
	
			throw new IllegalArgumentException("Invalid address");
		}
		
		this.contact_ID = contact_ID;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.phone_Number = phone_Number;
		this.contact_Address = contact_Address;
	}
	
	public static String getContactID() {
		
		return contact_ID;
	}
	
	public static String getContactFirstName() {
		
		return first_Name;
	}

	public static String getContactLastName() {
	
		return last_Name;
	}
	
	public static String getContactPhone() {
		
		return phone_Number;
	}

	public static String getContactAddress() { // getter methods to get contact info
	
		return contact_Address;
	}
}
